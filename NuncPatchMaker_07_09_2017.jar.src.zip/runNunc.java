/*    */ 
/*    */ 
/*    */ 
/*    */ public class runNunc
/*    */ {
/*    */   public static void main(String[] args) {
/*  7 */     windowNunc nuncij = new windowNunc();
/*    */     
/*  9 */     nuncij.setDefaultCloseOperation(3);
/* 10 */     nuncij.setSize(500, 560);
/* 11 */     nuncij.setResizable(false);
/*    */     
/* 13 */     nuncij.setVisible(true);
/*    */   }
/*    */ }


/* Location:              C:\Cloud\OneDrive - IN2 d.o.o. Koper\janus_razvoj\MARSIKAJ\NuncPatchMaker\NuncPatchMaker_07_09_2017.jar!\runNunc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */